import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Dashboard = () => {
  const { user, logout } = useAuth();

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Agent Management System</h1>
        <div className="user-info">
          <span>Welcome, {user?.email}</span>
          <button onClick={logout} className="logout-btn">Logout</button>
        </div>
      </header>

      <div className="dashboard-content">
        <div className="dashboard-cards">
          <Link to="/add-agent" className="dashboard-card">
            <h3>Add Agent</h3>
            <p>Add new agents to the system</p>
          </Link>

          <Link to="/upload-tasks" className="dashboard-card">
            <h3>Upload Tasks</h3>
            <p>Upload CSV file and distribute tasks</p>
          </Link>

          <Link to="/view-tasks" className="dashboard-card">
            <h3>View Tasks</h3>
            <p>View all tasks and their assignments</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
