import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ViewTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('http://localhost:4000/api/tasks');
      setTasks(response.data);
    } catch (error) {
      setError('Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading tasks...</div>;

  return (
    <div className="view-tasks-container">
      <nav className="breadcrumb">
        <Link to="/dashboard">Dashboard</Link> / View Tasks
      </nav>

      <h2>All Tasks</h2>

      {error && <div className="error-message">{error}</div>}

      {tasks.length === 0 ? (
        <p>No tasks found. <Link to="/upload-tasks">Upload some tasks</Link> to get started.</p>
      ) : (
        <div className="tasks-table-container">
          <table className="tasks-table">
            <thead>
              <tr>
                <th>First Name</th>
                <th>Phone</th>
                <th>Notes</th>
                <th>Assigned Agent</th>
                <th>Status</th>
                <th>Created At</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task) => (
                <tr key={task._id}>
                  <td>{task.firstName}</td>
                  <td>{task.phone}</td>
                  <td>{task.notes}</td>
                  <td>{task.assignedAgent?.name || 'Unassigned'}</td>
                  <td>
                    <span className={`status-badge status-${task.status}`}>
                      {task.status}
                    </span>
                  </td>
                  <td>{new Date(task.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ViewTasks;
