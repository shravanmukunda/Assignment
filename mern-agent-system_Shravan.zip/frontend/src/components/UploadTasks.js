import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const UploadTasks = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [distribution, setDistribution] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setError('');
    setMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!file) {
      setError('Please select a file');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://localhost:4000/api/tasks/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      setMessage(response.data.message);
      setDistribution(response.data.distribution);
      setFile(null);
      // Reset file input
      e.target.reset();
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to upload file');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="upload-tasks-container">
      <nav className="breadcrumb">
        <Link to="/dashboard">Dashboard</Link> / Upload Tasks
      </nav>

      <h2>Upload Tasks CSV</h2>

      <div className="upload-info">
        <h3>File Requirements:</h3>
        <ul>
          <li>Accepted formats: CSV, XLSX, XLS</li>
          <li>Required columns: FirstName, Phone, Notes</li>
          <li>Tasks will be distributed equally among all agents</li>
        </ul>
      </div>

      {message && <div className="success-message">{message}</div>}
      {error && <div className="error-message">{error}</div>}

      <form onSubmit={handleSubmit} className="upload-form">
        <div className="form-group">
          <label>Select File:</label>
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleFileChange}
            required
          />
        </div>

        <button type="submit" disabled={loading || !file}>
          {loading ? 'Uploading...' : 'Upload and Distribute'}
        </button>
      </form>

      {distribution && (
        <div className="distribution-summary">
          <h3>Distribution Summary:</h3>
          <table>
            <thead>
              <tr>
                <th>Agent Name</th>
                <th>Tasks Assigned</th>
              </tr>
            </thead>
            <tbody>
              {distribution.map((item, index) => (
                <tr key={index}>
                  <td>{item.agentName}</td>
                  <td>{item.taskCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default UploadTasks;
