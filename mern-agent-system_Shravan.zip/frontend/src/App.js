import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import AddAgent from './components/AddAgent';
import UploadTasks from './components/UploadTasks';
import ViewTasks from './components/ViewTasks';
import './App.css';

const ProtectedRoute = ({ children }) => {
  const { token } = useAuth();
  return token ? children : <Navigate to="/login" />;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/add-agent" 
              element={
                <ProtectedRoute>
                  <AddAgent />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/upload-tasks" 
              element={
                <ProtectedRoute>
                  <UploadTasks />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/view-tasks" 
              element={
                <ProtectedRoute>
                  <ViewTasks />
                </ProtectedRoute>
              } 
            />
            <Route path="/" element={<Navigate to="/dashboard" />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
